# Conditional WGAN-GP on CelebA blond hair

Course work for MSAI-630 (Generative AI with Large Language Models), University of the Cumberlands, Fall 2026 residency. The network is the conditional Wasserstein GAN with gradient penalty from David Foster, *Generative Deep Learning*, 2nd edition, notebook `04_gan/03_cgan`, itself adapted from Sayak Paul's Keras conditional-GAN tutorial.

**Turn in `MSAI-630_CGAN_Blond_Hair_Report.pdf`.** It is the submission document: the network, the `train_step` change, the shape-check output, samples from both classes, and the reading of fidelity, diversity, and conditioning. `cgan_blond_hair.ipynb` is the same work with the code executed. `MSAI-630_CGAN_Submission.zip` bundles the report, the notebook, the modules, and the figures.

The generator is conditioned on CelebA's `Blond_Hair` attribute. Class 0 is not blond, one-hot `[1, 0]`. Class 1 is blond, one-hot `[0, 1]`.

## What changed in `train_step`

The generator takes a noise vector of width 32 concatenated with that 2-class vector. The critic takes the RGB image concatenated with the same label repeated at every pixel, a map of shape `(64, 64, 2)`.

`train_step` is where the vector becomes the map. `expand_label_to_map` broadcasts the generator's one-hot across height and width before every critic call: real images, generated images, and the gradient penalty. Passing the vector straight into the critic does not match the critic input and raises a shape error. That check is written to `output/shape_audit.txt`.

## How to run

CelebA is not included. Put the attribute file and the aligned images here:

```text
data/list_attr_celeba.txt
data/img_align_celeba/000001.jpg
...
```

The originals are the non-commercial research release from the Multimedia Lab at the Chinese University of Hong Kong. A public copy of those two files is also hosted at `https://huggingface.co/datasets/Yuehao/celeba`.

```bash
pip install -r requirements.txt
python train.py --steps 2000
python evaluate.py
```

`train.py` resizes the faces to 64×64 once, then runs the notebook's training length: 2,000 updates, batch 128, critic steps 3, gradient-penalty weight 10, Adam at `5e-5` with betas `(0.5, 0.9)`.

## What to turn in

The run writes both classes, real and generated, under `output/`. The reading of those pictures is in `cgan_blond_hair.ipynb`.

| File | What it shows |
| --- | --- |
| `cgan_blond_hair.ipynb` | Code, the shape check, the samples, and the reading |
| `output/paired_step_2000.png` | Same noise in each column, label flipped across the row |
| `output/real_vs_generated.png` | Real faces beside samples of the same label |
| `output/label_difference_map.png` | Where the blond label moves pixels, averaged over shared noise |
| `output/label_luminance_gap.png` | Hair-band gap against the face-center gap |
| `output/loss_curves.png` | Critic estimate, gradient penalty, generator loss |
| `output/evaluation.json` | Diversity spread and the paired luminance gaps |
| `models/generator.weights.h5` | Weights that produced the samples |
